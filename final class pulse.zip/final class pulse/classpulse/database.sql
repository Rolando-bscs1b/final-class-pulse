CREATE DATABASE IF NOT EXISTS classpulse_revised CHARACTER SET utf8mb4;
USE classpulse_revised;
CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS teachers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS classes (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(20) NOT NULL, title VARCHAR(120) NOT NULL, teacher_id INT NOT NULL, FOREIGN KEY (teacher_id) REFERENCES teachers(id));
CREATE TABLE IF NOT EXISTS students (id INT AUTO_INCREMENT PRIMARY KEY, student_number VARCHAR(20) NOT NULL UNIQUE, email VARCHAR(150) NOT NULL UNIQUE, name VARCHAR(100) NULL, password_hash VARCHAR(255) NULL);
CREATE TABLE IF NOT EXISTS enrollments (student_id INT NOT NULL, class_id INT NOT NULL, PRIMARY KEY (student_id,class_id), FOREIGN KEY (student_id) REFERENCES students(id), FOREIGN KEY (class_id) REFERENCES classes(id));
CREATE TABLE IF NOT EXISTS sessions (id INT AUTO_INCREMENT PRIMARY KEY, class_id INT NOT NULL, started_at DATETIME DEFAULT CURRENT_TIMESTAMP, ended_at DATETIME NULL, INDEX(class_id,ended_at), FOREIGN KEY (class_id) REFERENCES classes(id));
CREATE TABLE IF NOT EXISTS responses (id INT AUTO_INCREMENT PRIMARY KEY, session_id INT NOT NULL, status ENUM('confused','following','bored') NULL, mood TINYINT NULL, message VARCHAR(500) NULL, clarity TINYINT NULL, pace TINYINT NULL, understanding TINYINT NULL, environment TINYINT NULL, participation TINYINT NULL, categories VARCHAR(255) NOT NULL DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX(session_id,created_at), FOREIGN KEY (session_id) REFERENCES sessions(id));
CREATE TABLE IF NOT EXISTS participation (session_id INT NOT NULL, student_id INT NOT NULL, PRIMARY KEY (session_id,student_id), FOREIGN KEY (session_id) REFERENCES sessions(id))
;
CREATE TABLE IF NOT EXISTS set_periods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  is_open TINYINT NOT NULL DEFAULT 1,
  results_released TINYINT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  open_slot TINYINT GENERATED ALWAYS AS (CASE WHEN is_open=1 THEN 1 ELSE NULL END) STORED,
  UNIQUE KEY one_open_set_period (open_slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS teaching_evaluations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  period_id INT NOT NULL,
  class_id INT NOT NULL,
  teacher_id INT NOT NULL,
  student_id INT NOT NULL,
  preparation TINYINT NOT NULL CHECK (preparation BETWEEN 1 AND 5),
  organization TINYINT NOT NULL CHECK (organization BETWEEN 1 AND 5),
  clarity TINYINT NOT NULL CHECK (clarity BETWEEN 1 AND 5),
  examples TINYINT NOT NULL CHECK (examples BETWEEN 1 AND 5),
  engagement TINYINT NOT NULL CHECK (engagement BETWEEN 1 AND 5),
  support TINYINT NOT NULL CHECK (support BETWEEN 1 AND 5),
  fairness TINYINT NOT NULL CHECK (fairness BETWEEN 1 AND 5),
  respect TINYINT NOT NULL CHECK (respect BETWEEN 1 AND 5),
  strengths VARCHAR(1500) NOT NULL DEFAULT '',
  improvements VARCHAR(1500) NOT NULL DEFAULT '',
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY one_set_per_class_cycle (period_id,class_id,student_id),
  INDEX set_teacher_results (teacher_id,period_id,class_id),
  FOREIGN KEY (period_id) REFERENCES set_periods(id),
  FOREIGN KEY (class_id) REFERENCES classes(id),
  FOREIGN KEY (teacher_id) REFERENCES teachers(id),
  FOREIGN KEY (student_id) REFERENCES students(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO set_periods (title)
SELECT 'Current SET cycle' WHERE NOT EXISTS (SELECT 1 FROM set_periods);
CREATE TABLE IF NOT EXISTS feature_settings (
  name VARCHAR(64) PRIMARY KEY,
  enabled TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO feature_settings (name,enabled) VALUES ('set',0);
ALTER TABLE set_periods ADD COLUMN questionnaire_version TINYINT NOT NULL DEFAULT 1, ADD COLUMN starts_at DATETIME NULL, ADD COLUMN ends_at DATETIME NULL;
ALTER TABLE set_periods ALTER COLUMN questionnaire_version SET DEFAULT 2;
ALTER TABLE classes ADD COLUMN branch VARCHAR(80) NOT NULL DEFAULT 'Naic', ADD COLUMN department VARCHAR(120) NOT NULL DEFAULT '', ADD COLUMN schedule_code VARCHAR(40) NOT NULL DEFAULT '';
ALTER TABLE teaching_evaluations ADD COLUMN questionnaire_version TINYINT NOT NULL DEFAULT 1, ADD COLUMN ratings_json TEXT NULL, ADD COLUMN comments VARCHAR(1500) NOT NULL DEFAULT '', MODIFY preparation TINYINT NULL DEFAULT NULL, MODIFY organization TINYINT NULL DEFAULT NULL, MODIFY clarity TINYINT NULL DEFAULT NULL, MODIFY examples TINYINT NULL DEFAULT NULL, MODIFY engagement TINYINT NULL DEFAULT NULL, MODIFY support TINYINT NULL DEFAULT NULL, MODIFY fairness TINYINT NULL DEFAULT NULL, MODIFY respect TINYINT NULL DEFAULT NULL;
UPDATE set_periods p SET questionnaire_version=2 WHERE NOT EXISTS (SELECT 1 FROM teaching_evaluations ev WHERE ev.period_id=p.id);
ALTER TABLE classes ADD COLUMN section_name VARCHAR(40) NOT NULL DEFAULT '';
ALTER TABLE students ADD COLUMN section_name VARCHAR(40) NOT NULL DEFAULT '';
ALTER TABLE sessions ADD COLUMN lesson_title VARCHAR(120) NOT NULL DEFAULT '';

ALTER TABLE teachers ADD COLUMN department VARCHAR(120) NOT NULL DEFAULT '';
