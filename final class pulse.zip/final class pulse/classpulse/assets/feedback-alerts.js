/* Anonymous status totals only; no student identity is used for alerts. */
(() => {
  const button = document.getElementById('feedback-sound');
  if (!button) return;
  const notice = document.getElementById('feedback-notice');
  let audio, enabled = false, sessionId = null, previous = 0;
  function chime() {
    if (!enabled || !audio || audio.state !== 'running') return;
    const now = audio.currentTime;
    [660, 880].forEach((frequency, index) => {
      const tone = audio.createOscillator(), volume = audio.createGain();
      tone.type = 'sine'; tone.frequency.value = frequency;
      volume.gain.setValueAtTime(0, now + index * .18);
      volume.gain.linearRampToValueAtTime(.12, now + index * .18 + .015);
      volume.gain.exponentialRampToValueAtTime(.001, now + index * .18 + .24);
      tone.connect(volume); volume.connect(audio.destination);
      tone.start(now + index * .18); tone.stop(now + index * .18 + .25);
    });
  }
  button.addEventListener('click', async () => {
    if (enabled) {
      enabled = false; button.textContent = 'Enable notification sound'; button.setAttribute('aria-pressed', 'false');
      notice.textContent = 'Sound muted. New Confused taps will still appear here.'; return;
    }
    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) throw new Error('unsupported');
      audio ||= new Audio();
      await audio.resume();
      if (audio.state !== 'running') throw new Error('blocked');
      enabled = true; button.textContent = 'Mute notification sound'; button.setAttribute('aria-pressed', 'true');
      notice.textContent = 'Sound enabled. Keep this live dashboard open to hear new anonymous feedback.'; chime();
    } catch {
      enabled = false; notice.textContent = 'Sound could not start. Check your browser sound permissions and try again.';
    }
  });
  window.updateFeedbackAlerts = data => {
    const session = data.session;
    const count = Number(data.count || 0);
    const id = session ? String(session.id) : null;
    // The first successful refresh establishes a baseline, including after changing sessions.
    if (id !== sessionId || sessionId === null) { sessionId = id; previous = count; return; }
    const added = Math.max(0, count - previous); previous = count;
    if (!session || session.ended_at || !added) return;
    notice.textContent = added === 1 ? 'New anonymous feedback received. Check your live feedback feed.' : `${added} new anonymous feedback received. Consider checking in with your class.`;
    chime();
  };
})();
