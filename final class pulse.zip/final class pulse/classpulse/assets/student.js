const form = document.getElementById('fb');
if (form) {
  const state = { status: null, mood: null, cats: new Set() };
  const pick = (box, attr, key) => box.querySelectorAll(attr).forEach(el => el.onclick = () => {
    box.querySelectorAll(attr).forEach(x => { x.classList.remove('active'); x.setAttribute('aria-pressed','false'); }); el.classList.add('active'); el.setAttribute('aria-pressed','true'); state[key] = el.dataset.v; });
  pick(document.getElementById('status'), '.status-btn', 'status');
  pick(document.getElementById('mood'), '.mood-btn', 'mood');
  document.querySelectorAll('#cats .chip').forEach(c => c.onclick = () => {
    c.classList.toggle('active'); c.setAttribute('aria-pressed', String(c.classList.contains('active'))); c.classList.contains('active') ? state.cats.add(c.dataset.v) : state.cats.delete(c.dataset.v); });
  const msg = document.getElementById('message');
  msg.oninput = () => document.getElementById('count').textContent = msg.value.length + '/500';
  const err = document.getElementById('msg');
  const submit = form.querySelector('button[type="submit"]');
  let submitting = false;
  form.onsubmit = async e => {
    e.preventDefault(); err.classList.add('d-none');
    if (submitting) return;
    const ratings = {};
    ['clarity','pace','understanding','environment','participation'].forEach(k => {
      const r = form.querySelector(`input[name=r_${k}]:checked`); if (r) ratings[k] = +r.value; });
    const body = { csrf: document.getElementById('csrf').value, class_id: +form.dataset.class, session_id: +form.dataset.session, status: state.status,
      mood: state.mood ? +state.mood : null, message: msg.value.trim(), ratings, categories: [...state.cats] };
    if (!body.status && !body.mood && !body.message && !Object.keys(ratings).length && !body.categories.length) {
      err.textContent = 'Please choose at least one response.'; err.classList.remove('d-none'); return; }
    submitting = true; submit.disabled = true; const submitText = submit.innerHTML; submit.textContent = 'Sending your feedback…'; form.setAttribute('aria-busy','true');
    try {
      const res = await fetch('api/submit.php', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
      const j = await res.json();
      if (!res.ok) { const error = new Error(j.error || 'Failed'); error.status=res.status; throw error; }
      form.classList.add('d-none'); document.getElementById('done').classList.remove('d-none'); document.getElementById('done').focus();
      if (typeof BroadcastChannel!=='undefined') { const channel=new BroadcastChannel('classpulse-live-feedback'); channel.postMessage({type:'feedback',class_id:body.class_id}); channel.close(); }
    } catch (x) { err.textContent = x instanceof SyntaxError ? 'We couldn’t send your feedback. Please try again.' : x.message === 'Failed to fetch' ? 'Connection problem. Please try again.' : x.message; err.classList.remove('d-none'); if (x.status===409 && typeof window!=='undefined') window.classPulseLive?.refresh(); }
    finally { submitting = false; submit.disabled = form.dataset.closed==='true'; submit.innerHTML = submitText; form.removeAttribute('aria-busy'); }
  };
  document.getElementById('again').onclick = () => location.reload();
}
const livePage=document.getElementById('feedback-live');
if (livePage) {
  const get=id=>document.getElementById(id), fields=get('live-fields'), badge=get('student-live-badge'), notice=get('live-notice');
  let timer,busy=false,stopped=false;
  function showState(state) {
    const original=Number(form.dataset.session), next=Number(state.session?.id || 0), changed=state.open && original!==0 && original!==next;
    const open=state.open && !changed;
    form.dataset.closed=String(!open); fields.disabled=!open;
    badge.textContent=state.open ? 'Feedback is open' : 'Feedback closed'; badge.classList.toggle('bg-success',state.open); badge.classList.toggle('bg-secondary',!state.open);
    get('student-lesson').textContent=state.session?.lesson_title || '';
    if (open) {
      if (!original) form.dataset.session=String(next);
      notice.classList.add('d-none'); get('live-reload').classList.add('d-none'); get('live-closed').classList.add('d-none');
      if (get('done').classList.contains('d-none')) form.classList.remove('d-none');
    } else {
      notice.textContent=changed ? 'A new lesson session has started. Join it before sending another response. Your current answers have not been sent.' : 'Your instructor has closed feedback. You are still signed in. Your unsent answers remain on this page.';
      notice.classList.remove('d-none'); get('live-reload').classList.toggle('d-none',!changed);
    }
  }
  async function refresh() {
    if (busy || stopped) return; busy=true; clearTimeout(timer);
    const controller=new AbortController(), timeout=setTimeout(()=>controller.abort(),8000);
    try {
      const response=await fetch('api/session-status.php?class_id='+encodeURIComponent(livePage.dataset.class),{cache:'no-store',credentials:'same-origin',signal:controller.signal});
      if (response.status===401 || response.status===403) { stopped=true; fields.disabled=true; form.dataset.closed='true'; notice.textContent=response.status===401 ? 'Your student sign-in has expired. Open the student login page to sign in again.' : 'You no longer have access to this class.'; notice.classList.remove('d-none'); return; }
      if (!response.ok) throw new Error('unavailable');
      showState(await response.json());
    } catch (error) { notice.textContent='Unable to check the session right now. Your answers are still here; reconnecting automatically.'; notice.classList.remove('d-none'); }
    finally { clearTimeout(timeout); busy=false; if (!stopped) timer=setTimeout(refresh,2000); }
  }
  window.classPulseLive={refresh}; window.addEventListener('focus',refresh); document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();}); refresh();
}
