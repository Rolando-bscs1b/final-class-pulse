<?php require __DIR__ . '/../includes/bootstrap.php'; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf();
    $s = db()->prepare('SELECT * FROM admins WHERE email=?'); $s->execute([trim($_POST['email'] ?? '')]); $a = $s->fetch();
    if ($a && password_verify($_POST['password'] ?? '', $a['password_hash'])) { session_regenerate_id(true); unset($_SESSION['teacher_id'], $_SESSION['student_id']); $_SESSION['admin_id'] = (int)$a['id']; header('Location: index.php'); exit; }
    $err = 'Invalid email or password.'; }
page_head('Admin Login'); $authRole = 'admin'; require __DIR__ . '/../includes/auth-view.php'; page_foot();
