<?php
require __DIR__ . '/../includes/bootstrap.php';
require_admin();
$isAdmin = true;
require __DIR__ . '/../includes/class-dashboard.php';
