CREATE TABLE IF NOT EXISTS set_periods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  is_open TINYINT NOT NULL DEFAULT 1,
  results_released TINYINT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  open_slot TINYINT GENERATED ALWAYS AS (CASE WHEN is_open=1 THEN 1 ELSE NULL END) STORED,
  UNIQUE KEY one_open_set_period (open_slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS teaching_evaluations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  period_id INT NOT NULL,
  class_id INT NOT NULL,
  teacher_id INT NOT NULL,
  student_id INT NOT NULL,
  preparation TINYINT NOT NULL CHECK (preparation BETWEEN 1 AND 5),
  organization TINYINT NOT NULL CHECK (organization BETWEEN 1 AND 5),
  clarity TINYINT NOT NULL CHECK (clarity BETWEEN 1 AND 5),
  examples TINYINT NOT NULL CHECK (examples BETWEEN 1 AND 5),
  engagement TINYINT NOT NULL CHECK (engagement BETWEEN 1 AND 5),
  support TINYINT NOT NULL CHECK (support BETWEEN 1 AND 5),
  fairness TINYINT NOT NULL CHECK (fairness BETWEEN 1 AND 5),
  respect TINYINT NOT NULL CHECK (respect BETWEEN 1 AND 5),
  strengths VARCHAR(1500) NOT NULL DEFAULT '',
  improvements VARCHAR(1500) NOT NULL DEFAULT '',
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY one_set_per_class_cycle (period_id,class_id,student_id),
  INDEX set_teacher_results (teacher_id,period_id,class_id),
  FOREIGN KEY (period_id) REFERENCES set_periods(id),
  FOREIGN KEY (class_id) REFERENCES classes(id),
  FOREIGN KEY (teacher_id) REFERENCES teachers(id),
  FOREIGN KEY (student_id) REFERENCES students(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO set_periods (title)
SELECT 'Current SET cycle' WHERE NOT EXISTS (SELECT 1 FROM set_periods);
