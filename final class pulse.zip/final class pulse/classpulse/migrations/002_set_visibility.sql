CREATE TABLE IF NOT EXISTS feature_settings (
  name VARCHAR(64) PRIMARY KEY,
  enabled TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO feature_settings (name,enabled) VALUES ('set',0);
