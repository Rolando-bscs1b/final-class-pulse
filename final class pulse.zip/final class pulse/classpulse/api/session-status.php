<?php
require __DIR__.'/../includes/live.php'; require_student(true);
header('Cache-Control: no-store, private');
$state=student_live_state((int)$_SESSION['student_id'],(int)($_GET['class_id'] ?? 0));
if (!$state) json_out(['error'=>'Not enrolled in this class'],403);
json_out($state);
