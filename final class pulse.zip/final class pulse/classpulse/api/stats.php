<?php require __DIR__ . '/../includes/bootstrap.php'; if (request_role()==='admin') { if (empty($_SESSION['admin_id'])) json_out(['error'=>'Not logged in'],401); } else require_teacher(true);
header('Cache-Control: no-store, private');
$cid = (int)($_GET['class_id'] ?? 0);
$c = db()->prepare('SELECT id FROM classes WHERE id=? AND (? = 1 OR teacher_id=?)'); $c->execute([$cid, empty($_SESSION['admin_id']) ? 0 : 1, $_SESSION['teacher_id'] ?? 0]);
if (!$c->fetch()) json_out(['error'=>'Forbidden'],403);
$s = db()->prepare('SELECT id,lesson_title,started_at,ended_at FROM sessions WHERE class_id=? ORDER BY id DESC LIMIT 1'); $s->execute([$cid]); $ses = $s->fetch();
if (!$ses) json_out(['session'=>null,'server_time'=>date('H:i:s')]);
$sid = $ses['id'];
function q(string $sql, int $sid) { $st = db()->prepare($sql); $st->execute([$sid]); return $st; }
$tot = q('SELECT COUNT(*) n, AVG(mood) mood, AVG(clarity) clarity, AVG(pace) pace, AVG(understanding) understanding, AVG(environment) environment, AVG(participation) participation FROM responses WHERE session_id=?', $sid)->fetch();
$status = ['confused'=>0,'following'=>0,'bored'=>0];
foreach (q('SELECT status, COUNT(*) n FROM responses WHERE session_id=? AND status IS NOT NULL GROUP BY status', $sid) as $r) $status[$r['status']] = (int)$r['n'];
$part = (int)q('SELECT COUNT(*) FROM participation WHERE session_id=?', $sid)->fetchColumn();
$enr = db()->prepare('SELECT COUNT(*) FROM enrollments WHERE class_id=?'); $enr->execute([$cid]); $enr = (int)$enr->fetchColumn();
$feed = q('SELECT message, status, mood, created_at, TIMESTAMPDIFF(MINUTE,created_at,NOW()) ago FROM responses WHERE session_id=? ORDER BY id DESC LIMIT 20', $sid)->fetchAll();
$concerns = [];
foreach (q("SELECT categories FROM responses WHERE session_id=? AND categories<>''", $sid) as $r) foreach (explode(',', $r['categories']) as $x) $concerns[$x] = ($concerns[$x] ?? 0) + 1;
arsort($concerns);
$tl = q("SELECT DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') t, status, COUNT(*) n FROM responses WHERE session_id=? AND status IS NOT NULL GROUP BY t,status ORDER BY t", $sid)->fetchAll();
$rnd = fn($v) => $v !== null ? round((float)$v, 1) : null;
json_out(['session'=>$ses,'count'=>(int)$tot['n'],'mood'=>$rnd($tot['mood']),
  'eval'=>['clarity'=>$rnd($tot['clarity']),'pace'=>$rnd($tot['pace']),'understanding'=>$rnd($tot['understanding']),'participation'=>$rnd($tot['participation']),'environment'=>$rnd($tot['environment'])],
  'status'=>$status,'enrolled'=>$enr,'participants'=>$part,'participation'=>$enr ? min(100,round($part/$enr*100)) : 0,'feed'=>$feed,'concerns'=>$concerns,'timeline'=>$tl,'server_time'=>date('H:i:s')]);
