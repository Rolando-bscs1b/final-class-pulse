<?php
// Database settings (XAMPP/WAMP defaults). Change for your server.
define('DB_HOST', 'localhost');
define('DB_NAME', 'classpulse_revised');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SUBMIT_COOLDOWN', 10); // seconds between submissions per student session
