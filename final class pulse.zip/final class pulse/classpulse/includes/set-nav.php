<?php
$workspaceRole=$workspaceRole ?? 'student';
$accountTable=['student'=>'students','teacher'=>'teachers','admin'=>'admins'][$workspaceRole];
$accountQuery=db()->prepare("SELECT name FROM $accountTable WHERE id=?"); $accountQuery->execute([$_SESSION[$workspaceRole.'_id']]); $accountName=$accountQuery->fetchColumn() ?: ucfirst($workspaceRole);
$dashboardPath=['student'=>'classes.php','teacher'=>'teacher/index.php','admin'=>'admin/index.php'][$workspaceRole];
$tasksPath=['student'=>'set.php','teacher'=>'teacher/evaluations.php','admin'=>'admin/evaluations.php'][$workspaceRole];
?>
<nav class="set-workspace-nav" aria-label="Evaluation workspace"><a class="wordmark" href="<?= e(app_url($dashboardPath)) ?>"><span class="brand-icon" aria-hidden="true">∿</span> ClassPulse</a><div class="set-workspace-links"><a href="<?= e(app_url($dashboardPath)) ?>">▦ <span>Dashboard</span></a><a href="<?= e(app_url($tasksPath)) ?>" aria-current="page">▣ <span><?= $workspaceRole==='student' ? 'My Tasks' : ($workspaceRole==='teacher' ? 'My Evaluations' : 'SET Management') ?></span></a></div><div class="set-account"><span class="set-avatar" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($accountName,0,1))) ?></span><span><?= e($accountName) ?></span><a href="<?= e(app_url($workspaceRole==='student' ? 'logout.php' : $workspaceRole.'/logout.php')) ?>" aria-label="Log out">↗</a></div></nav>
