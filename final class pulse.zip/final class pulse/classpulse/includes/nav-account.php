<?php
$navAccountRole = request_role();
$navAccountTable = ['student'=>'students','teacher'=>'teachers','admin'=>'admins'][$navAccountRole];
$navAccountQuery = db()->prepare("SELECT name FROM $navAccountTable WHERE id=?");
$navAccountQuery->execute([$_SESSION[$navAccountRole.'_id'] ?? 0]);
$navAccountName = $navAccountQuery->fetchColumn() ?: ucfirst($navAccountRole);
?>
<div class="portal-account" aria-label="Signed in as <?= e($navAccountName) ?>"><span class="portal-account-avatar" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($navAccountName,0,1))) ?></span><span class="portal-account-name"><?= e($navAccountName) ?></span></div>
