<?php
if (!isset($isAdmin)) { http_response_code(404); exit; }
if ($isAdmin) $classes = db()->query('SELECT * FROM classes ORDER BY code')->fetchAll();
else { require_teacher(); $cl = db()->prepare('SELECT * FROM classes WHERE teacher_id=? ORDER BY code'); $cl->execute([$_SESSION['teacher_id']]); $classes = $cl->fetchAll(); }
$cid = (int)($_GET['class_id'] ?? ($classes[0]['id'] ?? 0)); $cur = null;
foreach ($classes as $c) if ($c['id'] == $cid) $cur = $c;
if (!$cur) {
    http_response_code($classes ? 404 : 200);
    page_head('Dashboard');
    include __DIR__ . ($isAdmin ? '/../admin/nav.php' : '/../teacher/nav.php');
    echo '<main class="container portal py-5"><div class="card empty-card"><span class="empty-symbol" aria-hidden="true">∿</span><h1 class="h4 mt-4">'.($classes ? 'Class not found' : 'No classes assigned yet').'</h1><p>Choose an assigned class to view its feedback dashboard.</p><a class="btn btn-dark" href="index.php">Back to dashboard</a></div></main>';
    page_foot(); exit;
}
// Admins and instructors can start/close sessions, but only for classes in $classes (instructors: their own).
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf();
    if (!in_array($_POST['act'] ?? '', ['start', 'stop'], true)) { http_response_code(400); exit('Invalid session action.'); }
    if (!is_string($_POST['lesson_title'] ?? '')) { http_response_code(400); exit('Invalid lesson title.'); }
    try { change_live_session($cid,$_POST['act'],$_POST['lesson_title'] ?? ''); }
    catch (InvalidArgumentException $error) { http_response_code(400); exit(e($error->getMessage())); }
    header("Location: dashboard.php?class_id=$cid"); exit; }
page_head($isAdmin ? 'Admin Class Insights' : 'Teacher Live Dashboard');
include __DIR__ . ($isAdmin ? '/../admin/nav.php' : '/../teacher/nav.php'); ?>
<main class="container dashboard py-4" id="dash" data-class="<?= $cid ?>" data-role="<?= $isAdmin ? 'admin' : 'teacher' ?>">
  <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div><div class="dashboard-eyebrow">CLASS PULSE / <?= $isAdmin ? 'ADMIN' : 'INSTRUCTOR' ?></div><h1 class="dashboard-title">Your classroom, at a glance.</h1><p class="text-muted mb-3">Listen to your students. Find the moments that need attention.</p>
      <label class="visually-hidden" for="class-picker">Select class</label><select id="class-picker" class="form-select mt-1" onchange="location='?class_id='+this.value"><?php foreach ($classes as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $c['id']==$cid?'selected':'' ?>><?= e(class_label($c)) ?></option><?php endforeach; ?></select><div class="class-context mt-2"><span class="section-label"><?= e($cur['section_name'] ?: 'Section not assigned') ?></span><span class="department-label"><?= e($cur['department'] ?: 'Department not assigned') ?></span><span id="lesson-context">No lesson selected</span></div></div>
    <div class="d-flex flex-wrap align-items-center gap-2"><span class="badge bg-light text-dark border" role="status"><span class="live-dot off"></span><span id="connTxt">Connecting…</span></span>
      <form method="post" id="session-actions" class="d-flex flex-wrap gap-2"><input type="hidden" name="csrf" value="<?= csrf() ?>"><label class="visually-hidden" for="lesson-title">Lesson or topic for a new session</label><input id="lesson-title" class="form-control form-control-sm" name="lesson_title" maxlength="120" placeholder="Lesson / topic (optional)">
        <button name="act" value="start" class="btn btn-dark btn-sm">Start new session</button>
        <button name="act" value="stop" id="close-session" class="btn btn-outline-secondary btn-sm" disabled>Close feedback</button></form>
      <?php if ($isAdmin): ?><a href="../admin/index.php" class="small">← Admin</a>
      <?php else: ?><a href="index.php" class="small">← My classes</a><a href="logout.php" class="small">Log out</a><?php endif; ?></div></div>
  <section class="session-banner mb-4" aria-live="polite"><div><strong id="session-title">Loading session…</strong><div id="session-detail" class="small text-muted">Checking the latest classroom feedback.</div></div><button type="button" id="refresh" class="btn btn-outline-secondary btn-sm">Refresh now</button></section>
  <?php if (!$isAdmin): ?><section class="feedback-notifications mb-4" aria-label="Anonymous feedback notifications"><button type="button" id="feedback-sound" class="btn btn-outline-dark btn-sm" aria-pressed="false">Enable notification sound</button><span id="feedback-notice" class="small" role="status" aria-live="polite">Enable sound once on this page to hear new anonymous feedback during an open session.</span></section><?php endif; ?>
  <div id="connection-error" class="alert alert-warning d-none" role="alert"></div>
  <div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card p-3 text-center"><small>Average Mood</small><div class="display-5" id="mood">–</div><small>out of 5</small></div></div>
    <div class="col-md-3"><div class="card p-3 text-center"><small>Responses</small><div class="display-5" id="count">0</div><small>responses</small></div></div>
    <div class="col-md-3"><div class="card p-3 text-center"><small>Participation</small><div class="display-5" id="part">0%</div><small>of enrolled students</small></div></div>
    <div class="col-md-3"><div class="card p-3 h-100"><small>Live status taps</small>
      <div class="status-summary mt-3"><span><span aria-hidden="true">😕</span> <b id="s_confused">0</b><small>Confused</small></span><span><span aria-hidden="true">🙂</span> <b id="s_following">0</b><small>Following</small></span><span><span aria-hidden="true">😴</span> <b id="s_bored">0</b><small>Bored</small></span></div>
      <div class="small text-danger mt-1 d-none" id="alert">Many students are confused — consider pausing.</div></div></div>
  </div>
  <div class="row g-3">
    <div class="col-lg-6"><div class="card p-3"><h6>Live Feedback Feed</h6><div class="feed" id="feed"><div class="text-muted small">No messages yet.</div></div></div></div>
    <div class="col-lg-6"><div class="card p-3 mb-3"><h6>Evaluation Summary</h6><div id="eval"></div></div>
      <div class="card p-3 mb-3"><h6>Common Concerns</h6><div id="concerns" class="d-flex flex-wrap gap-2"></div></div>
      <div class="card p-3"><h6>Timeline <small class="text-muted">(by time, to find lecture parts needing attention)</small></h6><div id="timeline"></div>
        <div class="small mt-2"><span class="text-danger">■</span> Confused <span class="text-success ms-2">■</span> Following <span class="text-warning ms-2">■</span> Bored</div></div></div>
  </div>
  <div class="d-flex flex-wrap justify-content-between small text-muted mt-3 gap-2"><span>Feedback is anonymous · Status taps count submissions, not unique students.</span><span>Updated <span id="upd">–</span></span></div>
</main><?php if (!$isAdmin): ?><script src="<?= e(app_url('assets/feedback-alerts.js')) ?>?v=<?= filemtime(__DIR__.'/../assets/feedback-alerts.js') ?>"></script><?php endif; ?><?php page_foot('teacher.js');
