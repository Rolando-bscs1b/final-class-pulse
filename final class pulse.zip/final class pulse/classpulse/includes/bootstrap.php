<?php
require_once __DIR__ . '/../config.php';
date_default_timezone_set('Asia/Manila');
function app_url(string $path = ''): string {
    $root = str_replace('\\', '/', realpath(__DIR__ . '/..'));
    $script = str_replace('\\', '/', realpath($_SERVER['SCRIPT_FILENAME'] ?? '') ?: '');
    $base = '/classpulse';
    if (strpos($script, $root . '/') === 0 && isset($_SERVER['SCRIPT_NAME'])) {
        $relative = substr($script, strlen($root));
        $base = substr($_SERVER['SCRIPT_NAME'], 0, -strlen($relative));
    }
    return rtrim($base, '/') . '/' . ltrim($path, '/');
}
function request_role(): string {
    $path=str_replace('\\','/',$_SERVER['SCRIPT_NAME'] ?? '');
    if (preg_match('~/admin/[^/]+\.php$~',$path)) return 'admin';
    if (preg_match('~/teacher/[^/]+\.php$~',$path)) return 'teacher';
    if (str_ends_with($path,'/api/stats.php')) return ($_GET['role'] ?? '')==='admin' ? 'admin' : 'teacher';
    return 'student';
}
if (session_status()!==PHP_SESSION_ACTIVE) {
    session_name('CLASSPULSE_'.strtoupper(request_role()));
    session_set_cookie_params(['path'=>app_url(),'httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
    session_start();
}
function class_label(array $class): string {
    return $class['code'].' · '.(($class['section_name'] ?? '') ?: 'Section not assigned').' — '.$class['title'];
}
function change_live_session(int $classId,string $action,string $lesson=''): void {
    if (!in_array($action,['start','stop'],true)) throw new InvalidArgumentException('Invalid session action.');
    if (mb_strlen($lesson)>120) throw new InvalidArgumentException('Lesson titles must be 120 characters or fewer.');
    db()->beginTransaction();
    try {
        $lock=db()->prepare('SELECT id FROM classes WHERE id=? FOR UPDATE'); $lock->execute([$classId]);
        if (!$lock->fetch()) throw new DomainException('Class not found.');
        db()->prepare('UPDATE sessions SET ended_at=NOW() WHERE class_id=? AND ended_at IS NULL')->execute([$classId]);
        if ($action==='start') db()->prepare('INSERT INTO sessions (class_id,lesson_title) VALUES (?,?)')->execute([$classId,trim($lesson)]);
        db()->commit();
    } catch (Throwable $error) { if (db()->inTransaction()) db()->rollBack(); throw $error; }
}
function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    }
    return $pdo;
}
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function set_enabled(): bool {
    return (bool)db()->query("SELECT enabled FROM feature_settings WHERE name='set'")->fetchColumn();
}
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); }
function check_csrf(): void {
    if (empty($_SESSION['csrf']) || !is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) { http_response_code(403); exit('Invalid request.'); }
}
function json_out($d, $code = 200) { http_response_code($code); header('Content-Type: application/json'); echo json_encode($d); exit; }
function require_student(bool $json = false) {
    if (empty($_SESSION['student_id'])) {
        if ($json) json_out(['error'=>'Not logged in'],401);
        header('Location: '.app_url('login.php')); exit;
    }
}
function require_teacher(bool $json = false) {
    if (empty($_SESSION['teacher_id'])) {
        if ($json) json_out(['error'=>'Not logged in'],401);
        header('Location: '.app_url('teacher/login.php')); exit;
    }
}
function require_admin() {
    if (empty($_SESSION['admin_id'])) { header('Location: '.app_url('admin/login.php')); exit; }
}
function cvsu_email(string $m): bool { return (bool)preg_match('/^[A-Za-z0-9._%+-]+@cvsu\.edu\.ph$/i', $m); }
function page_head(string $title): void { ?>
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> | Class Pulse</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<meta name="theme-color" content="#176753"><link rel="stylesheet" href="<?= e(app_url('assets/style.css')) ?>?v=<?= filemtime(__DIR__.'/../assets/style.css') ?>"></head><body><?php }
function page_foot(string $js = ''): void { ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(app_url('assets/ui.js')) ?>?v=<?= filemtime(__DIR__.'/../assets/ui.js') ?>"></script>
<?php if ($js): ?><script src="<?= e(app_url('assets/'.$js)) ?>?v=<?= filemtime(__DIR__.'/../assets/'.$js) ?>"></script><?php endif; ?>
</body></html><?php }
