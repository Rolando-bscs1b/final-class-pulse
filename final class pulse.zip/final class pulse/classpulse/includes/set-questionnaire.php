<?php
function set_questions(int $version=2): array {
    if ($version===1) return set_legacy_questions();
    return [
      'q01'=>['Punctuality','Comes to class on time.'],
      'q02'=>['Course expectations','Explains learning outcomes, expectations, grading system, and various requirements of the subject/course.'],
      'q03'=>['Learning time','Maximizes the allocated time/learning hours effectively.'],
      'q04'=>['Critical and creative thinking','Facilitates students to think critically and creatively by providing appropriate learning activities.'],
      'q05'=>['Independent learning','Guides students to learn on their own, reflect on new ideas and experiences, and make decisions in accomplishing given tasks.'],
      'q06'=>['Constructive feedback','Communicates constructive feedback to students for their academic growth.'],
      'q07'=>['Subject knowledge','Demonstrates extensive and broad knowledge of the subject/course.'],
      'q08'=>['Clarity of explanation','Simplifies complex ideas in the lesson for ease of understanding.'],
      'q09'=>['Real-world connections','Relates the subject matter to contemporary issues and developments in the discipline and/or day-to-day life activities.'],
      'q10'=>['Active learning and ICT','Promotes active learning and student engagement by using appropriate teaching and learning tools including ICT tools and platforms.'],
      'q11'=>['Aligned assessment','Uses appropriate assessments (projects, exams, quizzes, assignments, etc.) aligned with the learning outcomes.'],
      'q12'=>['Student diversity','Recognizes and values the unique diversity and individual differences among students.'],
      'q13'=>['Consultation support','Assists students with their learning challenges during consultation hours.'],
      'q14'=>['Timely feedback','Provides immediate feedback on student outputs and performance.'],
      'q15'=>['Transparent criteria',"Provides transparent and clear criteria in rating student's performance."],
    ];
}
function set_sections(int $version=2): array {
    if ($version===1) return [['Legacy teaching evaluation','Original eight-question questionnaire',array_keys(set_questions(1))]];
    return [
      ['A. Management of Teaching and Learning','Classroom presence, clear expectations, effective use of time, and student-centered learning.', ['q01','q02','q03','q04','q05','q06']],
      ['B. Subject Knowledge and Teaching Strategies','Subject expertise, accessible explanations, relevant examples, and active learning.', ['q07','q08','q09','q10']],
      ['C. Assessment and Student Support','Aligned assessment, inclusion, consultation, timely feedback, and transparent grading.', ['q11','q12','q13','q14','q15']],
    ];
}
function set_scale(int $version=2): array {
    return $version===1 ? [5=>'Strongly agree',4=>'Agree',3=>'Neutral',2=>'Disagree',1=>'Strongly disagree'] : [5=>'Always manifested',4=>'Often manifested',3=>'Sometimes manifested',2=>'Seldom manifested',1=>'Never/Rarely manifested'];
}
function set_accepting(?array $period): bool {
    if (!$period || !$period['is_open']) return false;
    $now=(new DateTimeImmutable('now',new DateTimeZone('Asia/Manila')))->format('Y-m-d H:i:s');
    return (empty($period['starts_at']) || $period['starts_at']<=$now) && (empty($period['ends_at']) || $period['ends_at']>=$now);
}
function set_date(?string $date,bool $time=false): string {
    if (!$date) return 'Not scheduled';
    return (new DateTimeImmutable($date,new DateTimeZone('Asia/Manila')))->format($time ? 'M j, Y · g:i A' : 'M j, Y');
}
function set_input_date($value): ?string {
    if ($value===null || $value==='') return null;
    if (!is_string($value)) throw new DomainException('Enter a valid evaluation date.');
    $date=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$value,new DateTimeZone('Asia/Manila'));
    if (!$date || $date->format('Y-m-d\TH:i')!==$value) throw new DomainException('Enter a valid evaluation date.');
    return $date->format('Y-m-d H:i:s');
}
function set_task_status(array $period,bool $submitted=false): string {
    if ($submitted) return 'completed';
    if (set_accepting($period)) return 'available';
    $now=(new DateTimeImmutable('now',new DateTimeZone('Asia/Manila')))->format('Y-m-d H:i:s');
    return $period['is_open'] && !empty($period['starts_at']) && $period['starts_at']>$now ? 'pending' : 'closed';
}
function set_ratings(array $evaluation): array {
    $version=(int)($evaluation['questionnaire_version'] ?? 1);
    if ($version===2) return json_decode($evaluation['ratings_json'] ?? '{}',true) ?: [];
    return array_intersect_key($evaluation,set_questions(1));
}
function set_score_sql(string $alias='ev'): string {
    $legacy='('.implode('+',array_map(fn($key)=>$alias.'.'.$key,array_keys(set_questions(1)))).')/8';
    $modern='('.implode('+',array_map(fn($key)=>"CAST(JSON_UNQUOTE(JSON_EXTRACT($alias.ratings_json,'$.$key')) AS DECIMAL(4,2))",array_keys(set_questions(2)))).')/15';
    return "(CASE WHEN $alias.questionnaire_version=2 THEN $modern ELSE $legacy END)";
}
function set_render_questions(int $version,array $values=[],bool $readonly=false): void {
    $questions=set_questions($version); $number=0;
    foreach (set_sections($version) as [$title,$description,$keys]): ?>
    <section class="set-section"><h2><?= e($title) ?></h2><p class="set-section-description"><?= e($description) ?></p>
    <?php foreach ($keys as $key): $number++; [$label,$statement]=$questions[$key]; ?>
      <fieldset class="set-rating-question"><legend><?= $number ?>. <?= e($statement) ?> <?= !$readonly ? '<span class="required-mark" aria-hidden="true">*</span>' : '' ?></legend><div class="set-rating-scale">
      <?php foreach (set_scale($version) as $score=>$meaning): $selected=is_scalar($values[$key] ?? null) && (int)$values[$key]===$score; ?><div><input type="radio" id="set-<?= $key.$score ?>" name="<?= $key ?>" value="<?= $score ?>" <?= $selected ? 'checked' : '' ?> <?= $readonly ? 'disabled' : 'required' ?>><label for="set-<?= $key.$score ?>"><strong><?= $score ?></strong><span><?= e($meaning) ?></span><span class="visually-hidden"> · <?= e($label) ?></span></label></div><?php endforeach; ?>
      </div></fieldset>
    <?php endforeach; ?></section>
    <?php endforeach;
}
function set_render_sidebar(array $context,array $period,int $version): void { ?>
  <aside class="set-detail-sidebar"><h2>Evaluation details</h2><?php foreach ([['Form','Student Evaluation for Teacher'],['Teacher',$context['teacher'] ?? ''],['Class section',($context['section_name'] ?? '') ?: 'Section not assigned'],['Branch',$context['branch'] ?? 'Naic'],['Department',($context['department'] ?? '') ?: 'Not specified'],['Subject code',$context['code'] ?? ''],['Schedule code',($context['schedule_code'] ?? '') ?: 'Not specified'],['Subject title',$context['title'] ?? '']] as [$label,$value]): ?><div class="set-detail-tile"><span><?= e($label) ?></span><strong><?= e($value) ?></strong><?php if ($label==='Teacher' && !empty($context['teacher_email'])): ?><small><?= e($context['teacher_email']) ?></small><?php endif; ?></div><?php endforeach; ?><div class="set-detail-numbers"><div class="set-detail-tile"><span>Sections</span><strong><?= count(set_sections($version))+1 ?></strong></div><div class="set-detail-tile"><span>Questions</span><strong><?= count(set_questions($version))+1 ?></strong></div></div><div class="set-detail-tile"><span>Available until</span><strong><?= empty($period['ends_at']) ? 'Until admin closes the cycle' : e(set_date($period['ends_at'],true)) ?></strong></div><p class="set-detail-footnote"><?= e($period['title']) ?><?= $version===1 ? ' · Original 8-question form' : '' ?></p></aside>
<?php }
