<?php require_once 'includes/bootstrap.php'; require_student();
$cid = (int)($_GET['class_id'] ?? 0);
$q = db()->prepare('SELECT c.*, t.name AS teacher FROM classes c JOIN teachers t ON t.id=c.teacher_id
  JOIN enrollments e ON e.class_id=c.id AND e.student_id=? WHERE c.id=?');
$q->execute([$_SESSION['student_id'], $cid]); $c = $q->fetch();
if (!$c) { header('Location: classes.php'); exit; }
$s = db()->prepare('SELECT id,lesson_title FROM sessions WHERE class_id=? AND ended_at IS NULL ORDER BY id DESC LIMIT 1'); $s->execute([$cid]); $liveSession=$s->fetch(); $open=(bool)$liveSession;
$items = ['clarity'=>'The lesson is clear.','pace'=>'The pace of the class is appropriate.','understanding'=>'I understand what I am expected to learn.','environment'=>'I feel comfortable asking questions.','participation'=>'The teacher encourages participation.'];
$cats = ['Too fast','Too slow','Need more examples','Need clarification','Good explanation','Good pace','More activities','Other'];
page_head('Feedback'); include __DIR__ . '/includes/student-nav.php'; ?>
<main class="feedback-layout" id="feedback-live" data-class="<?= $cid ?>">
  <a href="classes.php" class="back-link">← Back to my classes</a>
  <div class="feedback-heading"><div class="d-flex justify-content-between align-items-center mb-3"><span class="class-code"><?= e($c['code']) ?></span>
    <span id="student-live-badge" class="badge <?= $open ? 'bg-success' : 'bg-secondary' ?>"><?= $open ? 'Feedback is open' : 'Closed' ?></span></div>
  <h1><?= e($c['title']) ?></h1><div class="text-muted"><?= e($c['teacher']) ?></div><div class="class-context mt-3"><span class="section-label"><?= e($c['section_name'] ?: 'Section not assigned') ?></span><span id="student-lesson"><?= e($liveSession['lesson_title'] ?? '') ?></span></div></div>
  <div class="anonymous-banner"><span aria-hidden="true">◈</span><div><strong>A safe space for your perspective</strong><span>Your response is anonymous. Share only what you’re comfortable with.</span></div></div>
  <div id="live-notice" class="alert alert-warning <?= $open ? 'd-none' : '' ?>" role="status"><?= $open ? '' : 'Feedback is closed. You are still signed in. This page will update when your instructor opens a session.' ?></div><a id="live-reload" class="btn btn-outline-dark mb-3 d-none" href="feedback.php?class_id=<?= $cid ?>">Join the new session</a>
  <section id="live-closed" class="card empty-card <?= $open ? 'd-none' : '' ?>"><span class="empty-symbol" aria-hidden="true">∿</span><h2>We’re waiting for the next check-in.</h2><p>Your instructor controls when feedback is open. Closing feedback does not log you out.</p><a href="classes.php" class="btn btn-dark">Back to my classes</a></section>
  <form id="fb" class="<?= $open ? '' : 'd-none' ?>" data-class="<?= $cid ?>" data-session="<?= $liveSession['id'] ?? 0 ?>" data-closed="<?= $open ? 'false' : 'true' ?>"><input type="hidden" id="csrf" value="<?= csrf() ?>"><fieldset id="live-fields" <?= $open ? '' : 'disabled' ?>>
    <section class="feedback-section"><div class="feedback-section-heading"><span class="section-number">01</span><div><h2>How are you following along?</h2><p>Pick the option that feels closest to you right now.</p></div></div>
    <div class="row g-2 mb-3" id="status">
      <?php foreach (['confused'=>['😕','Confused'],'following'=>['🙂','Following'],'bored'=>['😴','Bored']] as $k=>$v): ?>
      <div class="col-4"><button type="button" class="status-btn" data-v="<?= $k ?>" aria-pressed="false"><span class="em" aria-hidden="true"><?= $v[0] ?></span><?= $v[1] ?></button></div><?php endforeach; ?>
    </div>
    <h3 class="h6 mt-4">How does the class feel today?</h3>
    <div class="row g-1 text-center mb-3" id="mood">
      <?php foreach ([1=>['😣','Very difficult'],2=>['😟','Difficult'],3=>['😐','Okay'],4=>['🙂','Good'],5=>['😄','Great']] as $n=>$v): ?>
      <div class="col"><button type="button" class="mood-btn" data-v="<?= $n ?>" aria-pressed="false"><span class="em" aria-hidden="true"><?= $v[0] ?></span><?= $v[1] ?></button></div><?php endforeach; ?>
    </div>
    </section><section class="feedback-section"><div class="feedback-section-heading"><span class="section-number">02</span><div><h2><label for="message">Anything you’d like to share?</label></h2><p>A question, a suggestion, or something that helped you learn.</p></div></div>
    <textarea id="message" maxlength="500" rows="4" class="form-control" aria-describedby="message-help count" placeholder="One thing I’d like my teacher to know…"></textarea>
    <div class="d-flex justify-content-between small text-muted mt-2"><span id="message-help">Optional · Please leave out personal details.</span><span id="count">0/500</span></div></section>
    <section class="feedback-section"><div class="feedback-section-heading"><span class="section-number">03</span><div><h2>A quick look at the lesson</h2><p id="rating-help">Optional · 1 = strongly disagree, 5 = strongly agree.</p></div></div>
    <?php foreach ($items as $k=>$label): ?>
    <fieldset class="rate" aria-describedby="rating-help"><legend><?= e($label) ?></legend><div class="rating-options">
      <?php for ($i=1;$i<=5;$i++): ?><input type="radio" name="r_<?= $k ?>" id="<?= $k.$i ?>" value="<?= $i ?>"><label for="<?= $k.$i ?>"><span class="visually-hidden"><?= e($label) ?>: </span><?= $i ?></label><?php endfor; ?></div></fieldset>
    <?php endforeach; ?>
    </section><section class="feedback-section"><div class="feedback-section-heading"><span class="section-number">04</span><div><h2>What stands out?</h2><p>Optional · Choose any topics you’d like to highlight.</p></div></div>
    <div class="d-flex flex-wrap gap-2" id="cats"><?php foreach ($cats as $x): ?><button type="button" class="chip" data-v="<?= e($x) ?>" aria-pressed="false"><?= e($x) ?></button><?php endforeach; ?></div></section>
    <div id="msg" class="alert alert-danger py-2 small d-none" role="alert"></div>
    <button class="btn btn-dark w-100 py-3" type="submit">Send anonymous feedback <span aria-hidden="true">→</span></button>
    <p class="small text-center text-muted mt-2">No name or identifying information will be attached to your response.</p>
  </fieldset></form>
  <div id="done" class="card empty-card d-none" role="status" tabindex="-1"><span class="success-symbol" aria-hidden="true">✓</span><h2>You’ve made yourself heard.</h2>
    <p class="text-muted">Thank you for helping improve the class.<br>Your response was submitted anonymously.</p>
    <a class="btn btn-dark w-100" href="classes.php">Done</a><button class="btn btn-link" id="again">Send another update</button></div>
</main><?php page_foot('student.js');
