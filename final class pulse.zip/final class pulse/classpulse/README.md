# ClassPulse (PHP + MySQL + Bootstrap + JavaScript)
Live feedback uses separate student/teacher/admin login sessions. Sign in once again after upgrading. Teacher feeds refresh automatically, including status-only check-ins; closing feedback keeps the student signed in and preserves unsent answers on the open page.
Apply `migrations/004_sections_live.sql` to existing databases after migrations 001–003. The local database is already upgraded. Assign sections in Admin → Students and Classes, create one class entry per subject/section, and manage enrollment for each section. SET result charts include response counts and rating distributions while retaining teacher anonymity rules.
SET visibility is controlled from **Admin → SET → Turn on SET / Hide SET**. It is hidden from students and teachers by default. Visibility does not change cycles or delete evaluations. Existing databases need `migrations/002_set_visibility.sql` in addition to the SET schema migration; fresh setup includes both.
SET is available from the student dashboard when enabled by an admin. Students submit one evaluation per enrolled class per cycle. New cycles use the user-supplied 15-question manifestation scale and an optional comments field, in a dark task-card workspace with a details sidebar. Completed submissions are view-only. Older eight-question records keep their original form and scores. Teachers see only their own anonymous summaries after admin release and at least three responses; admins can inspect identified submissions. Live feedback remains anonymous.
Existing installations need `migrations/003_set_reference.sql` after migrations 001 and 002. This adds questionnaire versioning, optional cycle dates, and editable branch/department/schedule metadata. The local installation is already upgraded. Start a new cycle from Admin → SET to use the 15-question form; SET remains hidden until **Turn on SET** is selected.
For existing databases, import `migrations/001_set.sql` into the configured database before installing the updated application. Fresh installs using `setup.php` include the SET schema and an open starter cycle.
Includes a complete responsive UI refresh for the welcome page, all sign-in pages, student classes and feedback, teacher dashboards, and admin management. Admin directories support local search; feedback controls work with keyboard navigation. No database migration is needed for the UI update.
The revised app uses the separate `classpulse_revised` database. Its starter data includes 1 admin, 3 instructors, 4 classes, and 20 students. Feedback starts empty.
Admin portal: `/classpulse/admin/login.php` → school overview and management. Teacher portal: `/classpulse/teacher/login.php` → assigned classes and live feedback. If installed in a parent folder, include that folder before `/classpulse` in these URLs. Each portal has its own dashboard pages and access checks.
1. Copy `classpulse` to `htdocs`. Edit `config.php` if needed.
2. Open `/classpulse/setup.php` once (creates/upgrades DB + demo data), then delete it.
3. Logins (change all demo passwords):
   - Student: 2023-0001 or student1@cvsu.edu.ph / student123
   - Instructor: santos@cvsu.edu.ph / teacher123  -> /teacher/login.php
   - Admin: admin@cvsu.edu.ph / admin123 -> /admin/login.php
Admin manages instructors, classes, students, enrollment, and starts/closes feedback sessions. Instructors have their own overview and start/close sessions for their own classes.
Responses store no student ID; `participation` records only who took part.
